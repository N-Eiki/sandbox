# -*- coding: utf-8 -*-
"""
Python確認用プログラム
Copyright(c) 2018 Koji Makino and Hiromitsu Nishizaki All Rights Reserved.
"""
print('Hello DQN!')
